<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM bookings WHERE id = '$user_id' AND certificate_status = 'approved'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $student = mysqli_fetch_assoc($result);
    $student_name = htmlspecialchars($student['name']);
    $class_name = htmlspecialchars($student['dance_class']);
    $completion_date = date("d-m-Y");
} else {
    echo "<h2>No Approved Certificate Found!</h2>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate of Completion</title>
    <style>
        body { background-color: #f9f9f9; font-family: 'Georgia', serif; text-align: center; padding: 50px; }
        .certificate { border: 10px solid #6a1b9a; padding: 50px; background-color: #fff; width: 80%; margin: auto; border-radius: 20px; }
        h1 { color: #6a1b9a; font-size: 50px; }
        .student-name { font-size: 35px; margin: 20px 0; color: #333; }
        .course-name { font-size: 30px; margin: 20px 0; color: #555; }
        .date { font-size: 20px; color: #777; margin-top: 30px; }
        .signature { margin-top: 50px; font-size: 18px; color: #333; }
        button { margin-top: 30px; padding: 15px 30px; font-size: 18px; background-color: #6a1b9a; color: white; border: none; border-radius: 8px; cursor: pointer; }
        button:hover { background-color: #4a0072; }
    </style>
</head>
<body>

<div class="certificate">
    <h1>Certificate of Completion</h1>
    <p>This is to certify that</p>
    <div class="student-name"><?php echo $student_name; ?></div>
    <p>has successfully completed the</p>
    <div class="course-name"><?php echo $class_name; ?></div>
    <div class="date">Date: <?php echo $completion_date; ?></div>
    <div class="signature">Instructor Signature</div>
</div>

<button onclick="window.print()">Download / Print Certificate</button>

</body>
</html>
