<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Store booking details in session for future use
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['booking_name'] = $_POST['name'];
    $_SESSION['booking_class'] = $_POST['class'];
    $_SESSION['booking_date'] = $_POST['date'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Page</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .payment-container { background-color: #fff; padding: 30px; border-radius: 10px; width: 400px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; }
        label { display: block; margin-top: 15px; }
        input { width: 100%; padding: 10px; margin-top: 5px; }
        button { width: 100%; padding: 12px; background-color: #4CAF50; color: white; margin-top: 20px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>
<div class="payment-container">
    <h2>Payment Details</h2>
    <form action="payment_success.php" method="POST">
        <label>Total Amount (Rs):</label>
        <input type="text" name="amount" value="500" readonly>

        <label>Card Number:</label>
        <input type="text" name="card_number" placeholder="XXXX-XXXX-XXXX-XXXX" required>

        <label>Expiry Date:</label>
        <input type="text" name="expiry" placeholder="MM/YY" required>

        <label>CVV:</label>
        <input type="password" name="cvv" placeholder="123" required>

        <button type="submit">Pay Now</button>
    </form>
</div>
</body>
</html>
