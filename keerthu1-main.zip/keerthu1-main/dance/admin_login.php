<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="dance_booking";
$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error){
    die("Connection failed: ".$conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM admin_user WHERE username=?";
    
    
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
      
        if(hash('sha256', $password) === $row['password_hash']){
            $_SESSION['admin_username'] = $username;
            header("Location: admin.php");
            exit();
        } else {
            $error_message = "Invalid password.";
        }
    } else {
        $error_message = "User not found.";
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body{
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('purple1.jpeg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container{
            background: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 8px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        h1{
            margin-top: 0;
            font-size: 24px;
            color:rgba(104, 90, 230, 0.49);
        }
        h2{
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group{
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label{
            color: #333;
            font-size: 14px;
        }
        .form-group input{
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group input:focus{
            border-color:rgba(104, 90, 230, 0.49);
            outline: none;
        }
        .login-btn{
            width: 100%;
            padding: 10px;
            background:rgba(104, 90, 230, 0.49);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-btn:hover{
            background:rgba(104, 90, 230, 0.49);
        }
        .links{
            margin-top: 15px;
        }
        .links a{
            color::rgba(104, 90, 230, 0.49);
            text-decoration: none;
            font-size: 14px;
        }
        .links a:hover{
            text-decoration: underline;
        }
        .error-message{
            color: red;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>ADMIN LOGIN</h1>
        <h2>Welcome Back!</h2>

        <?php
        if (isset($error_message)) {
            echo "<div class='error-message'>$error_message</div>";
        }
        ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Enter Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Enter Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
            <div class="links">
                <a href="#">Forgot password?</a>
                <a href="index.php">Home page</a>
            </div>
        </form>
    </div>
</body>
</html>
