<?php
include('db.php'); 

$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $age = (int) $_POST['age'];
    $dance_class = mysqli_real_escape_string($conn, $_POST['dance_class']);
    $schedule = mysqli_real_escape_string($conn, $_POST['schedule']);
    $experience = mysqli_real_escape_string($conn, $_POST['experience']);

    
    $query = "SELECT fees FROM dance_booking WHERE class_name = '$dance_class'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $fees = $row['fees'];

       
        $insert_query = "INSERT INTO bookings (name, email, phone, age, dance_class, schedule, experience, fees) 
                         VALUES ('$name', '$email', '$phone', $age, '$dance_class', '$schedule', '$experience', $fees)";

        if (mysqli_query($conn, $insert_query)) {
            $success_message = "Your booking has been successfully received! We will contact you shortly.";
        } else {
            $error_message = "Error: " . mysqli_error($conn);
        }
    } else {
        $error_message = "Invalid dance class selection.";
    }
}


mysqli_close($conn);
?>
